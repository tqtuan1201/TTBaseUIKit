//
//  TTBaseUIKit.h
//  TTBaseUIKit
//
//  Created by Truong Quang Tuan on 4/5/19.
//  Copyright © 2019 Truong Quang Tuan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TTBaseUIKit.
FOUNDATION_EXPORT double TTBaseUIKitVersionNumber;

//! Project version string for TTBaseUIKit.
FOUNDATION_EXPORT const unsigned char TTBaseUIKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TTBaseUIKit/PublicHeader.h>


