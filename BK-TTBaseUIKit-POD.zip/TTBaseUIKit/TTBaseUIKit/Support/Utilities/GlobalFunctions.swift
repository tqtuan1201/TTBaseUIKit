//
//  Appsss.swift
//  TTBaseUIKit
//
//  Created by Truong Quang Tuan on 4/15/19.
//  Copyright © 2019 Truong Quang Tuan. All rights reserved.
//

var TTSize:SizeConfig { get { return TTBaseUIKitConfig.getSizeConfig() } }
var TTView:ViewConfig { get { return TTBaseUIKitConfig.getViewConfig() } }
var TTFont:FontConfig { get { return TTBaseUIKitConfig.getFontConfig() } }
var TTStyle:StyleConfig { get { return TTBaseUIKitConfig.getStyleConfig() } }
